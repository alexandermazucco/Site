Fuentes deFharo: Gratis s�lo para uso personal (FFP)

En esta licencia, �el tipo de letra� se refiere al archivo. Zip dado que puede contener uno o numerosos tipos de letra u otros archivos. Estas fuentes pueden ser de cualquier tipo (. Ttf,. Otf, webfonts) y juntos forman una �familia de fuentes� o en definitiva un �tipo de letra�.
1. Derechos de autor
El tipo de letra determinado es de propiedad intelectual de Fernando Haro, y est� protegido por leyes de derechos de autor en muchas partes del mundo.

2. Uso Personal
El tipo de letra determinado puede ser descargado y utilizado gratuitamente para su uso personal, siempre que el uso no sea racista o ilegal. El uso personal se refiere a todo uso que no genere ingresos financieros de una manera comercial, por ejemplo:

- Portafolios personales
� Sitios web y blogs recreativos para los amigos y la familia
� Impresiones en folletos, carteles, camisetas , etc. para organizaciones ben�ficas y organizaciones sin �nimo de lucro

3. Uso Comercial
El uso comercial no est� permitido sin el consentimiento previo por escrito del autor (Fernando Haro). Por favor, compre una licencia comercial. El uso comercial se refiere al uso en un entorno empresarial, incluyendo:

- Tarjetas de visita, logotipos, publicidad, sitios web para empresas
� Camisetas, libros, prendas de vestir que se venden por dinero
� Folletos, carteles para eventos que cobran admisi�n
� Trabajos de dise�o gr�fico freelance
� Cualquier cosa que genere ingresos directos o indirectos

4. Modificaci�n
El tipo de letra determinado no podr� ser modificado, alterado, adaptados o construidos en ellas sin permiso escrito del autor. Esto concierne a todos los archivos incluidos en el archivo .zip
Lea los t�rminos y condiciones de la licencia comercial

5. Distribuci�n
Los tipos de letra pueden ser copiados y pasados a otras personas para uso privado siempre que se distribuya el archivo .zip original. Los tipos de letra no pueden ser vendidos sin el consentimiento escrito de deFharo. Puede publicar en su web los tipos de letra para descarga gratuita siempre que mencione al autor (defharo.com)

6. Renuncia
El tipo de letra dada se ofrece �tal cual� sin ninguna garant�a. deFharo.com autor del tipo de letra determinado no ser� responsable de los da�os derivados del uso de este tipo de letra.
Al utilizar cualquiera de mis tipos de letra, usted acepta los t�rminos de esta licencia.

==============================================

Fonts deFharo: Free for personal use License (FFP)

In this license, �the given typeface� refers to the given .zip file, which may contain one or numerous fonts. These fonts can be of any type (.ttf, .otf, �) and together they form a �font family� or in short a �typeface�.
1. Copyright
The given typeface is the intellectual property of deFharo, provided it is original, and is protected by copyright laws in many parts of the world.

2. Personal Use
The given typeface may be downloaded and used free of charge for personal use, as long as the usage is not racist or illegal. Personal use refers to all usage that does not generate financial income in a business manner, for instance:

- personal books for yourself
� recreational websites and blogs for friends and family
� prints such as flyers, posters, t-shirts for churches, charities, and non-profit organizations

3. Commercial Use
Commercial use is not allowed without prior written permission from the author deFharo. Please contact to ask for commercial licensing. Commercial use refers to usage in a business environment, including:

- business cards, logos, advertising, websites for companies
� t-shirts, books, apparel that will be sold for money
� flyers, posters for events that charge admission
� freelance graphic design work
� anything that will generate direct or indirect income

4. Modification
The given typeface may not be modified, altered, adapted or built upon without written permission by deFharo. This pertains all files within the downloadable font zip-file.

5. Distribution
While the given typeface may freely be copied and passed along to other individuals for private use as its original downloadable zip-file, it may not be sold or published without written permission by deFharo.

6. Disclaimer
The given typeface is offered �as is� without any warranty. deFharo.com author of the given typeface shall not be liable for any damage derived from using this typeface.

By using the given typeface you agree to the terms of this license.

